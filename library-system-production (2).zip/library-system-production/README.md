# Library Management System

A complete Library Management System built with **PHP (OOP)** and **MySQL (PDO)**. This system features a modular MVC architecture, Admin Authentication, and Report Generation.

## Features
- **Books Module**: CRUD operations, Search by Title/Author.
- **Members Module**: CRUD operations, Borrowing History.
- **Borrow & Return Module**: Manage book circulation, track overdue items.
- **Admin Module**: Secure Login/Logout, Profile management.
- **Reports Module**: Statistical summaries, Overdue reports, Most borrowed books.
- **Security**: Password Hashing, Session Management, API Authentication.

## Project Structure
```
/library-system
├── config/
│   └── database.php       # Database Connection
├── controllers/           # Business Logic
│   ├── AdminController.php
│   ├── BookController.php
│   ├── BorrowController.php
│   ├── MemberController.php
│   └── ReportController.php
├── helpers/
│   ├── Auth.php           # Authentication Middleware
│   ├── Response.php       # Standard JSON Response
│   └── Validator.php      # Input Validation
├── models/                # Database Interactions
│   ├── Admin.php
│   ├── Book.php
│   ├── Borrow.php
│   ├── Member.php
│   └── Report.php
├── routes/
│   └── api.php            # API Routing
└── setup.sql              # Database Schema
```

## Setup Instructions
1.  **Database Setup**:
    - Create a database named `library_db` (or as configured in `config/database.php`).
    - Import `setup.sql` to create tables and default admin.
2.  **Configuration**:
    - Update `config/database.php` if your credentials differ from default (`root`/``).
3.  **Run**:
    - Place the project in your server's root (e.g., `htdocs`).
    - Access the API via `http://localhost/library-system/routes/api.php/...`.

## API Endpoints (Summary)

### Public
- None (All currently secured or assumed secured by context, though some Book search might be public if Auth check was moved). *Note: Current implementation protects ALL routes except Admin Login.*

### Admin / Protected
- **Auth**: `POST /admin/login`, `POST /admin/logout`
- **Books**: `GET /books`, `POST /books`, `PUT /books?id=1`, `DELETE /books?id=1`
- **Members**: `GET /members`, `POST /members`, ...
- **Borrow**: `POST /borrow`, `POST /return`, `GET /borrowed`
- **Reports**: `GET /reports/summary`, `GET /reports/overdue`

## Testing
Run the included test script from the command line:
```bash
php test_full_system.php
```
