<?php
// Simple CLI test script to verify Member endpoints using cURL
$baseUrl = 'http://localhost/library-system/routes/api.php';

function makeRequest($url, $method, $data = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $httpCode, 'body' => json_decode($response, true)];
}

echo "Testing Member Module API...\n\n";

// 1. Create a Member
echo "1. Creating a member...\n";
$newMember = [
    'name' => 'Jane Doe',
    'email' => 'jane.doe@example.com',
    'phone' => '123-456-7890'
];
$resp = makeRequest("$baseUrl/members", 'POST', $newMember);
echo "Status: " . $resp['code'] . "\n";
print_r($resp['body']);
echo "\n";

// 2. Get all members
echo "2. Getting all members...\n";
$resp = makeRequest("$baseUrl/members", 'GET');
echo "Status: " . $resp['code'] . "\n";
// print_r($resp['body']);
echo "Count: " . (isset($resp['body']['data']) ? count($resp['body']['data']) : 0) . "\n\n";

// Get ID of the last created member (assuming DESC order)
$memberId = isset($resp['body']['data'][0]['id']) ? $resp['body']['data'][0]['id'] : null;

if ($memberId) {
    // 3. Get Member by ID
    echo "3. Getting member by ID ($memberId)...\n";
    $resp = makeRequest("$baseUrl/members?id=$memberId", 'GET');
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";

    // 4. Update Member
    echo "4. Updating member ($memberId)...\n";
    $updateData = $newMember;
    $updateData['name'] = 'Jane Smith';
    $resp = makeRequest("$baseUrl/members?id=$memberId", 'PUT', $updateData);
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";

    // 5. Get Borrow History (likely empty)
    echo "5. Getting borrow history for member ($memberId)...\n";
    $resp = makeRequest("$baseUrl/members/history?id=$memberId", 'GET');
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";

    // 6. Delete Member
    echo "6. Deleting member ($memberId)...\n";
    $resp = makeRequest("$baseUrl/members?id=$memberId", 'DELETE');
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";
} else {
    echo "Could not retrieve member ID for further tests.\n";
}
