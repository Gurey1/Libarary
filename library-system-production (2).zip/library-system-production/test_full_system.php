<?php
// Test Script for Library System
// Run this with "php test_full_system.php"

include_once 'config/database.php';
include_once 'models/Admin.php';

// Helper to print section headers
function printHeader($title) {
    echo "\n" . str_repeat("=", 40) . "\n";
    echo " TEST: " . $title . "\n";
    echo str_repeat("=", 40) . "\n";
}

// 1. Verify Database Tables (Basic Check)
printHeader("Database Connection");
$database = new Database();
$db = $database->connect();
if ($db) {
    echo "[PASS] Database connected.\n";
} else {
    echo "[FAIL] Database connection failed.\n";
    exit;
}

// 2. Create a Test Admin
printHeader("Create Test Admin");
$username = "admin_test_" . rand(1000, 9999);
$password = "secret123";
$hashed = password_hash($password, PASSWORD_DEFAULT);

$stmt = $db->prepare("INSERT INTO admins (username, password) VALUES (:u, :p)");
$stmt->bindParam(':u', $username);
$stmt->bindParam(':p', $hashed);
if ($stmt->execute()) {
    echo "[PASS] Created admin user: $username\n";
} else {
    echo "[FAIL] Could not create admin user (maybe already exists).\n";
}

// 3. Simulation of Login (Direct Model Call)
printHeader("Admin Login (Model)");
$admin = new Admin($db);
if ($admin->login($username, $password)) {
    echo "[PASS] Admin login valid for correct credentials.\n";
} else {
    echo "[FAIL] Admin login failed for correct credentials.\n";
}

if (!$admin->login($username, "wrongpass")) {
    echo "[PASS] Admin login failed for wrong credentials (expected).\n";
} else {
    echo "[FAIL] Admin login SUCCEEDED for wrong credentials!\n";
}

// 4. Verify Files Exist
printHeader("File Existence Check");
$files = [
    'models/Borrow.php',
    'controllers/BorrowController.php',
    'models/Admin.php',
    'controllers/AdminController.php',
    'helpers/Auth.php'
];

foreach ($files as $file) {
    if (file_exists($file)) {
        echo "[PASS] File exists: $file\n";
    } else {
        echo "[FAIL] File MISSING: $file\n";
    }
}

echo "\nVerification Complete. Manual testing via Postman/Browser recommended for full Route/Session testing.\n";
