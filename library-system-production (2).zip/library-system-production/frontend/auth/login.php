<?php
// frontend/auth/login.php
// Redirect if already logged in
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Library Management System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }
        .login-card {
            width: 100%;
            max-width: 400px;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .login-header {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            color: white;
            padding: 2rem;
            border-radius: 12px 12px 0 0;
            text-align: center;
        }
        .logo-icon {
            font-size: 3rem;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <div class="card login-card">
        <div class="login-header">
            <i class="fas fa-book-reader logo-icon"></i>
            <h4>Library System</h4>
            <p class="mb-0 small text-white-50">Authorized Access Only</p>
        </div>
        <div class="card-body p-4">
            
            <div id="error-alert" class="alert alert-danger d-none shadow-sm" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i> <span id="error-msg"></span>
            </div>

            <form id="login-form">
                <div class="mb-3">
                    <label for="email" class="form-label fw-bold">Email or Username</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control" id="email" name="email" placeholder="Enter your credentials" required autofocus>
                    </div>
                </div>

                <div class="mb-4">
                    <label for="password" class="form-label fw-bold">Password</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold" id="login-btn">
                    <span id="loading-spinner" class="spinner-border spinner-border-sm me-2 d-none" role="status"></span>
                    Sign In
                </button>
            </form>

            <div class="text-center mt-3">
                <a href="#" class="text-decoration-none small text-muted">Forgot password?</a>
            </div>
        </div>
        <div class="card-footer bg-white border-top-0 text-center py-3">
            <small class="text-muted">&copy; 2025 Library Management System</small>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/api.js"></script>
    <script src="../js/auth.js"></script>
    <script>
        // Redirect if already logged in (Frontend Logic)
        if (localStorage.getItem('token')) {
             window.location.href = '../dashboard/index.php';
        }
    </script>
</body>
</html>
