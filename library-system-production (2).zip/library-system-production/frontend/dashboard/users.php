<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<!-- Page Content -->
<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
        <div class="d-flex align-items-center">
            <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
            <h2 class="fs-4 m-0">Users Management</h2>
        </div>
    </nav>

    <div class="container-fluid px-4 py-4">
        
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <div class="input-group w-50">
                    <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
                    <input type="text" class="form-control border-start-0 ps-0" id="search-input" placeholder="Search by name or email...">
                </div>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">
                    <i class="fas fa-user-plus me-2"></i>Add User
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Full Name</th>
                                <th>Contact</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="users-table-body">
                            <!-- JS Generated -->
                        </tbody>
                    </table>
                </div>
                <!-- Pagination -->
                <nav class="d-flex justify-content-end p-3">
                    <ul class="pagination mb-0" id="pagination"></ul>
                </nav>
            </div>
        </div>

    </div>
</div>

<!-- Add/Edit User Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">Add New User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="user-form">
                    <input type="hidden" id="u_id">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="u_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" id="u_email" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input type="text" class="form-control" id="u_phone">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save User</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    let currentPage = 1;
    let searchQuery = '';

    document.addEventListener('DOMContentLoaded', () => {
        loadUsers();

        // Search Debounce
        document.getElementById('search-input').addEventListener('input', (e) => {
            searchQuery = e.target.value;
            loadUsers(1);
        });

        // Form Submit
        document.getElementById('user-form').addEventListener('submit', handleFormSubmit);
    });

    async function loadUsers(page = 1) {
        currentPage = page;
        /* Using GET /api/users, support q=search and page=X if API allows.
           Assuming API supports standard REST response with 'data' array.
        */
        const res = await API.request(`/users?page=${page}&q=${searchQuery}`);
        
        if (res && res.status === 200) {
            renderTable(res.data.data);
            // renderPagination(res.data.meta); // If API returns meta
        }
    }

    function renderTable(users) {
        const tbody = document.getElementById('users-table-body');
        if (!users || users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4 text-muted">No users found.</td></tr>';
            return;
        }

        tbody.innerHTML = users.map(u => `
            <tr>
                <td class="ps-4 text-muted">#${u.id}</td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="avatar-circle me-2 bg-primary text-white d-flex align-items-center justify-content-center rounded-circle" style="width:32px;height:32px;font-size:12px;">
                            ${u.full_name.charAt(0).toUpperCase()}
                        </div>
                        <span class="fw-bold">${u.full_name}</span>
                    </div>
                </td>
                <td>
                    <div class="d-flex flex-column small">
                        <span>${u.email}</span>
                        <span class="text-muted">${u.phone || ''}</span>
                    </div>
                </td>
                <td>
                    <span class="badge rounded-pill bg-${u.status === 'Active' ? 'success' : 'danger'} bg-opacity-10 text-${u.status === 'Active' ? 'success' : 'danger'}">
                        ${u.status}
                    </span>
                </td>
                <td class="text-end pe-4">
                    <button class="btn btn-sm btn-outline-primary me-1" onclick="openEditModal(${u.id}, '${u.full_name}', '${u.email}', '${u.phone || ''}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-${u.status === 'Active' ? 'danger' : 'success'}" onclick="toggleStatus(${u.id}, '${u.status}')">
                        <i class="fas fa-${u.status === 'Active' ? 'ban' : 'check'}"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }

    async function handleFormSubmit(e) {
        e.preventDefault();
        const id = document.getElementById('u_id').value;
        const data = {
            full_name: document.getElementById('u_name').value,
            email: document.getElementById('u_email').value,
            phone: document.getElementById('u_phone').value
        };

        let res;
        if (id) {
            res = await API.request(`/users/${id}`, 'PUT', data);
        } else {
            res = await API.request('/users', 'POST', data);
        }

        if (res && res.status === 200) {
            bootstrap.Modal.getInstance(document.getElementById('addUserModal')).hide();
            // Reset form
            document.getElementById('u_id').value = '';
            document.getElementById('user-form').reset();
            loadUsers(currentPage);
        } else {
            alert('Operation failed: ' + (res.data.message || 'Unknown error'));
        }
    }

    function openEditModal(id, name, email, phone) {
        document.getElementById('modalTitle').innerText = 'Edit User';
        document.getElementById('u_id').value = id;
        document.getElementById('u_name').value = name;
        document.getElementById('u_email').value = email;
        document.getElementById('u_phone').value = phone;
        new bootstrap.Modal(document.getElementById('addUserModal')).show();
    }

    async function toggleStatus(id, currentStatus) {
        const newStatus = currentStatus === 'Active' ? 'Suspended' : 'Active';
        if (confirm(`Change status to ${newStatus}?`)) {
            await API.request(`/users/${id}/status`, 'PATCH', { status: newStatus });
            loadUsers(currentPage);
        }
    }
</script>

<?php include '../includes/footer.php'; ?>
