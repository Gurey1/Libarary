<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>

<!-- Page Content -->
<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom py-3 px-4">
        <div class="d-flex align-items-center">
            <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
            <h2 class="fs-4 m-0">Dashboard</h2>
        </div>
        
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle second-text fw-bold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user me-2"></i>Admin
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="settings.php">Settings</a></li>
                        <li><a class="dropdown-item" href="#" onclick="API.logout()">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid px-4 py-4">
        
        <!-- KPI Row -->
        <div class="row g-3 my-2">
            <div class="col-md-3">
                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                    <div>
                        <h3 class="fs-2" id="kpi-books">0</h3>
                        <p class="fs-5 text-muted">Total Books</p>
                    </div>
                    <i class="fas fa-book fs-1 primary-text border rounded-full secondary-bg p-3"></i>
                </div>
            </div>

            <div class="col-md-3">
                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                    <div>
                        <h3 class="fs-2" id="kpi-borrowed">0</h3>
                        <p class="fs-5 text-muted">Borrowed</p>
                    </div>
                    <i class="fas fa-hand-holding fs-1 text-warning border rounded-full secondary-bg p-3"></i>
                </div>
            </div>

            <div class="col-md-3">
                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                    <div>
                        <h3 class="fs-2" id="kpi-users">0</h3>
                        <p class="fs-5 text-muted">Users</p>
                    </div>
                    <i class="fas fa-users fs-1 text-info border rounded-full secondary-bg p-3"></i>
                </div>
            </div>

            <div class="col-md-3">
                <div class="p-3 bg-white shadow-sm d-flex justify-content-around align-items-center rounded">
                    <div>
                        <h3 class="fs-2 text-danger">$<span id="kpi-fines">0</span></h3>
                        <p class="fs-5 text-muted">Unpaid Fines</p>
                    </div>
                    <i class="fas fa-chart-line fs-1 text-danger border rounded-full secondary-bg p-3"></i>
                </div>
            </div>
        </div>

        <div class="row my-5">
            <h3 class="fs-4 mb-3">Recent Activity</h3>
            <div class="col-lg-8">
                <canvas id="borrowChart" width="400" height="200"></canvas>
            </div>
             <div class="col-lg-4">
                <canvas id="categoryChart" width="400" height="200"></canvas>
            </div>
        </div>

    </div>
</div>

<script src="../js/dashboard.js"></script>

<?php include '../includes/footer.php'; ?>
