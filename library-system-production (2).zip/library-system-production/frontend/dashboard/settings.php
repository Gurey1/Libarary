<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
         <h2 class="fs-4 m-0">System Settings</h2>
    </nav>

    <div class="container-fluid px-4 py-4">
        
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white">
                        <h5 class="m-0">Configuration</h5>
                    </div>
                    <div class="card-body">
                        <form id="settings-form">
                            <div class="mb-3">
                                <label class="form-label">Library Name</label>
                                <input type="text" class="form-control" name="library_name" required>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                     <label class="form-label">Borrow Limit (Days)</label>
                                     <input type="number" class="form-control" name="borrow_days_limit" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                     <label class="form-label">Fine Per Day ($)</label>
                                     <input type="number" step="0.01" class="form-control" name="fine_per_day" required>
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Max Books Per User</label>
                                <input type="number" class="form-control" name="max_books_per_user" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Save Changes
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                 <div class="card bg-info bg-opacity-10 border-0">
                     <div class="card-body">
                         <h5><i class="fas fa-info-circle me-2"></i>Help</h5>
                         <p class="small text-muted mb-0">
                             These settings affect global business logic. Changing "Fine Per Day" will apply to all future fine calculations. Max books limit is enforced on new checkouts.
                         </p>
                     </div>
                 </div>
            </div>
        </div>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', async () => {
         // Load
         const res = await API.request('/settings');
         if (res && res.status === 200) {
             const data = res.data.data;
             const form = document.querySelector('form');
             // Populate fields by name
             form.library_name.value = data.library_name || '';
             form.borrow_days_limit.value = data.borrow_days_limit || 14;
             form.fine_per_day.value = data.fine_per_day || 1.00;
             form.max_books_per_user.value = data.max_books_per_user || 5;
         }

         // Save
         document.getElementById('settings-form').addEventListener('submit', async (e) => {
             e.preventDefault();
             const payload = {
                 settings: {
                     library_name: e.target.library_name.value,
                     borrow_days_limit: e.target.borrow_days_limit.value,
                     fine_per_day: e.target.fine_per_day.value,
                     max_books_per_user: e.target.max_books_per_user.value
                 }
             };
             
             const updateRes = await API.request('/settings/update', 'POST', payload);
             if (updateRes && updateRes.status === 200) {
                 alert('Settings saved successfully!');
             } else {
                 alert('Error saving settings');
             }
         });
    });
</script>

<?php include '../includes/footer.php'; ?>
