<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
         <h2 class="fs-4 m-0">Reports & Analytics</h2>
    </nav>

    <div class="container-fluid px-4 py-4">
        <div class="row g-4">
            <!-- Reuse Dashboard Chart Logic for detailed view -->
            <div class="col-md-6">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white">
                        <h5 class="m-0">Monthly Borrowing Trends</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="detailBorrowChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white">
                        <h5 class="m-0">Inventory Distribution</h5>
                    </div>
                    <div class="card-body">
                         <canvas id="detailCategoryChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="col-12">
                 <div class="card shadow-sm border-0">
                     <div class="card-header bg-white">
                         <h5 class="m-0">Top Borrowed Books</h5>
                     </div>
                     <div class="card-body">
                         <div class="list-group list-group-flush" id="top-books-list"></div>
                     </div>
                 </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', async () => {
        // Load Borrowing Chart
        const bRes = await API.request('/reports/borrowings');
        if (bRes && bRes.status === 200) {
             renderBarChart(bRes.data.data);
        }

        // Load Categories
        const cRes = await API.request('/reports/books');
        if (cRes && cRes.status === 200) {
            renderPieChart(cRes.data.data.by_category);
            renderTopBooks(cRes.data.data.most_borrowed);
        }
    });

    function renderBarChart(data) {
        new Chart(document.getElementById('detailBorrowChart'), {
            type: 'bar',
            data: {
                labels: data.map(d => d.month),
                datasets: [{
                    label: 'Borrowings',
                    data: data.map(d => d.count),
                    backgroundColor: '#0d6efd'
                }]
            }
        });
    }

    function renderPieChart(data) {
        new Chart(document.getElementById('detailCategoryChart'), {
            type: 'pie',
            data: {
                labels: data.map(d => d.name || 'Other'),
                datasets: [{
                    data: data.map(d => d.count),
                    backgroundColor: ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#6f42c1']
                }]
            }
        });
    }

    function renderTopBooks(data) {
        document.getElementById('top-books-list').innerHTML = data.map((b, i) => `
            <div class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <span class="badge bg-secondary me-2">#${i+1}</span>
                    <span class="fw-bold">${b.title}</span>
                </div>
                <span class="badge bg-primary rounded-pill">${b.borrow_count} borrowings</span>
            </div>
        `).join('');
    }
</script>

<?php include '../includes/footer.php'; ?>
