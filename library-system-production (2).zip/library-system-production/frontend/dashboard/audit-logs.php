<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
         <h2 class="fs-4 m-0">System Audit Logs</h2>
    </nav>

    <div class="container-fluid px-4 py-4">
        <div class="card shadow-sm border-0">
             <div class="card-body p-0">
                <table class="table table-hover mb-0 font-monospace small">
                    <thead class="bg-dark text-white">
                        <tr>
                            <th class="ps-3">Timestamp</th>
                            <th>Admin</th>
                            <th>Action</th>
                            <th>Details</th>
                            <th class="text-end pe-3">IP Address</th>
                        </tr>
                    </thead>
                    <tbody id="logs-body"></tbody>
                </table>
             </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', async () => {
         const res = await API.request('/audit-logs');
         if (res && res.status === 200) {
             document.getElementById('logs-body').innerHTML = res.data.data.map(l => `
                <tr>
                    <td class="ps-3 text-muted">${l.created_at}</td>
                    <td class="fw-bold">${l.admin_name || 'System'}</td>
                    <td><span class="badge bg-secondary">${l.action}</span></td>
                    <td>${l.details}</td>
                    <td class="text-end pe-3 text-muted">${l.ip_address}</td>
                </tr>
             `).join('');
         }
    });
</script>

<?php include '../includes/footer.php'; ?>
