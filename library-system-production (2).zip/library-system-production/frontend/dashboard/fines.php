<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
         <h2 class="fs-4 m-0">Fines & Penalties</h2>
    </nav>

    <div class="container-fluid px-4 py-4">
        
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body">
                <div class="d-flex align-items-center justify-content-between">
                     <div>
                         <h5 class="text-muted">Total Unpaid</h5>
                         <h2 class="text-danger fw-bold">$<span id="total-unpaid">0.00</span></h2>
                     </div>
                     <i class="fas fa-hand-holding-usd fs-1 text-danger opacity-25"></i>
                </div>
            </div>
        </div>

        <div class="card shadow-sm border-0">
             <div class="card-header bg-white py-3">
                 <h5 class="m-0">Outstanding Fines</h5>
             </div>
             <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Fine ID</th>
                                <th>User</th>
                                <th>Book / Transaction</th>
                                <th>Days Late</th>
                                <th>Amount</th>
                                <th class="text-end pe-4">Payment</th>
                            </tr>
                        </thead>
                        <tbody id="fines-table-body"></tbody>
                    </table>
                </div>
             </div>
        </div>

    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', loadFines);

    async function loadFines() {
        const res = await API.request('/fines');
        if (res && res.status === 200) {
            const fines = res.data.data;
            const tbody = document.getElementById('fines-table-body');
            
            // Calculate Total
            const total = fines
                .filter(f => f.status === 'unpaid')
                .reduce((acc, curr) => acc + parseFloat(curr.amount), 0);
            document.getElementById('total-unpaid').innerText = total.toFixed(2);

            tbody.innerHTML = fines.map(f => `
                <tr>
                    <td class="ps-4 text-muted">#${f.id}</td>
                    <td>${f.user_name}</td>
                    <td>
                        <div class="small text-muted">Tx #${f.transaction_id}</div>
                        ${f.book_title}
                    </td>
                    <td>${f.days_late} Days</td>
                    <td class="fw-bold text-danger">$${parseFloat(f.amount).toFixed(2)}</td>
                    <td class="text-end pe-4">
                         ${f.status === 'unpaid' ? 
                            `<button class="btn btn-sm btn-success" onclick="payFine(${f.id})">
                                <i class="fas fa-check-circle me-1"></i>Mark Paid
                            </button>` : 
                            '<span class="badge bg-secondary">PAID</span>'}
                    </td>
                </tr>
            `).join('');
        }
    }

    async function payFine(id) {
        if (confirm('Confirm payment of this fine?')) {
            const res = await API.request(`/fines/pay/${id}`, 'POST');
            if (res && res.status === 200) {
                loadFines();
            } else {
                alert('Payment failed');
            }
        }
    }
</script>

<?php include '../includes/footer.php'; ?>
