<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
        <h2 class="fs-4 m-0">Books Inventory</h2>
    </nav>

    <div class="container-fluid px-4 py-4">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <input type="text" class="form-control w-50" id="search-book" placeholder="Search by title, author, ISBN...">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBookModal">
                    <i class="fas fa-plus me-2"></i>Add Book
                </button>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">ID</th>
                                <th>Details</th>
                                <th>ISBN</th>
                                <th>Availability</th>
                                <th class="text-end pe-4">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="books-table-body"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addBookModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Book Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="book-form">
                    <div class="mb-3">
                        <label>Title</label>
                        <input type="text" class="form-control" id="b_title" required>
                    </div>
                    <div class="mb-3">
                        <label>Author</label>
                        <input type="text" class="form-control" id="b_author" required>
                    </div>
                    <div class="mb-3">
                        <label>ISBN</label>
                        <input type="text" class="form-control" id="b_isbn" required>
                    </div>
                    <div class="row">
                        <div class="col-6 mb-3">
                            <label>Year</label>
                            <input type="number" class="form-control" id="b_year" max="2099">
                        </div>
                        <div class="col-6 mb-3">
                            <label>Total Copies</label>
                            <input type="number" class="form-control" id="b_copies" min="1" value="1" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Save Book</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        loadBooks();
        document.getElementById('book-form').addEventListener('submit', handleBookSubmit);
        document.getElementById('search-book').addEventListener('input', (e) => loadBooks(e.target.value));
    });

    async function loadBooks(query = '') {
        const endpoint = query ? `/books?q=${query}` : '/books';
        const res = await API.request(endpoint);
        
        if (res && res.status === 200) {
            const tbody = document.getElementById('books-table-body');
            tbody.innerHTML = res.data.data.map(b => `
                <tr>
                    <td class="ps-4 text-muted">#${b.id}</td>
                    <td>
                        <div class="fw-bold">${b.title}</div>
                        <div class="small text-muted">${b.author} (${b.published_year})</div>
                    </td>
                    <td>${b.isbn}</td>
                     <td>
                        <span class="badge ${b.available_copies > 0 ? 'bg-success' : 'bg-warning text-dark'}">
                            ${b.available_copies} / ${b.total_copies} available
                        </span>
                    </td>
                    <td class="text-end pe-4">
                        <button class="btn btn-sm btn-outline-danger" onclick="deleteBook(${b.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `).join('');
        }
    }

    async function handleBookSubmit(e) {
        e.preventDefault();
        const data = {
            title: document.getElementById('b_title').value,
            author: document.getElementById('b_author').value,
            isbn: document.getElementById('b_isbn').value,
            published_year: document.getElementById('b_year').value,
            total_copies: document.getElementById('b_copies').value,
            available_copies: document.getElementById('b_copies').value
        };

        const res = await API.request('/books', 'POST', data);
        if (res && res.status === 200) {
             bootstrap.Modal.getInstance(document.getElementById('addBookModal')).hide();
             document.getElementById('book-form').reset();
             loadBooks();
        } else {
             alert('Failed to save book');
        }
    }

    async function deleteBook(id) {
        if (confirm('Are you sure you want to delete this book?')) {
            await API.request(`/books/${id}`, 'DELETE');
            loadBooks();
        }
    }
</script>

<?php include '../includes/footer.php'; ?>
