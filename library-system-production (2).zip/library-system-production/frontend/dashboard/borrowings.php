<?php require_once '../includes/auth_check.php'; ?>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>

<div id="page-content-wrapper" class="w-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom px-4 py-3">
        <h2 class="fs-4 m-0">Borrowing Transactions</h2>
    </nav>

    <div class="container-fluid px-4 py-4">
        
        <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#checkoutModal">
            <i class="fas fa-barcode me-2"></i>Checkout Book
        </button>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                 <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Trans ID</th>
                                <th>Borrower</th>
                                <th>Book Details</th>
                                <th>Timeline</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Return/Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tx-table-body"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">New Checkout</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form id="checkout-form">
                    <div class="mb-3">
                        <label>User ID</label>
                         <input type="number" class="form-control" id="c_user_id" required placeholder="Scan user card ID...">
                    </div>
                    <div class="mb-3">
                        <label>Book ID</label>
                        <input type="number" class="form-control" id="c_book_id" required placeholder="Scan book ID...">
                    </div>
                    <div class="mb-3">
                        <label>Duration (Days)</label>
                        <input type="number" class="form-control" id="c_days" value="14">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Checkout</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        loadTransactions();
        document.getElementById('checkout-form').addEventListener('submit', handleCheckout);
    });

    async function loadTransactions() {
        const res = await API.request('/transactions');
        if (res && res.status === 200) {
            const tbody = document.getElementById('tx-table-body');
            tbody.innerHTML = res.data.data.map(t => {
                const now = new Date();
                const due = new Date(t.due_date);
                const isLate = (t.status === 'borrowed' && now > due);
                
                return `
                <tr>
                    <td class="ps-4 text-muted">#${t.id}</td>
                    <td>
                        <div class="fw-bold">${t.user_name}</div>
                        <div class="small text-muted">ID: ${t.user_id}</div>
                    </td>
                    <td>${t.book_title}</td>
                    <td>
                        <div class="small">
                            <i class="fas fa-arrow-up text-success me-1"></i> ${t.borrow_date}<br>
                            <i class="fas fa-arrow-down text-danger me-1"></i> ${t.due_date}
                        </div>
                    </td>
                    <td>
                        <span class="badge bg-${getStatusColor(t.status, isLate)}">
                            ${isLate ? 'OVERDUE' : t.status.toUpperCase()}
                        </span>
                    </td>
                    <td class="text-end pe-4">
                        ${t.status === 'borrowed' ? 
                            `<button class="btn btn-sm btn-outline-success" onclick="returnBook(${t.id})">
                                <i class="fas fa-undo me-1"></i>Return
                            </button>` : 
                            '<span class="text-muted small">Closed</span>'}
                    </td>
                </tr>
            `}).join('');
        }
    }

    function getStatusColor(status, isLate) {
        if (status === 'returned') return 'secondary';
        if (isLate) return 'danger';
        return 'primary';
    }

    async function handleCheckout(e) {
        e.preventDefault();
        const data = {
            user_id: document.getElementById('c_user_id').value,
            book_id: document.getElementById('c_book_id').value,
            days: document.getElementById('c_days').value
        };

        const res = await API.request('/borrow', 'POST', data);
        if (res && res.status === 200) {
            alert('Checkout Successful!');
            bootstrap.Modal.getInstance(document.getElementById('checkoutModal')).hide();
            document.getElementById('checkout-form').reset();
            loadTransactions();
        } else {
            alert(res.data.message || 'Checkout failed');
        }
    }

    async function returnBook(id) {
        if (confirm('Process return for this item? Fines will be calculated automatically.')) {
            const res = await API.request('/return', 'POST', { transaction_id: id });
            if (res && res.status === 200) {
                 alert(res.data.message); // Contains fine info
                 loadTransactions();
            } else {
                alert('Error processing return');
            }
        }
    }
</script>

<?php include '../includes/footer.php'; ?>
