<?php
// frontend/includes/auth_check.php

// 1. Prevent Browser Caching
// This ensures that clicking "Back" after logout validates authentication again.
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>

<script>
    /**
     * Global Authentication Guard
     * Validates JWT Token from LocalStorage before rendering the page.
     */
    (function() {
        // 1. Check for Token existence
        const token = localStorage.getItem('token');
        
        if (!token) {
            console.warn('Authentication Guard: No token found. Redirecting...');
            redirectToLogin();
            return;
        }

        // 2. Validate Token Format & Expiry
        try {
            const parts = token.split('.');
            if (parts.length !== 3) {
                throw new Error('Token structure invalid');
            }

            // Decode payload (Base64Url decoding)
            const base64Url = parts[1];
            const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
            const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            }).join(''));
            
            const payload = JSON.parse(jsonPayload);
            
            // Check Expiry (exp is in seconds, Date.now() is ms)
            if (payload.exp && (payload.exp * 1000 < Date.now())) {
                throw new Error('Token expired');
            }

            // Optional: Role Check (if needed later)
            // console.log('Authenticated as User ID:', payload.sub);

        } catch (error) {
            console.error('Authentication Guard Failed:', error.message);
            localStorage.removeItem('token'); // Clear bad token
            redirectToLogin();
        }

        function redirectToLogin() {
            // Adjust path based on current location to ensure we hit login.php
            // Assuming this runs in /dashboard/..., we go up one level to /auth/login.php
            // Or use absolute path if server root is known. Using relative safely:
            
            // Construct login URL dynamically or fixed
            window.location.href = '/library-system/frontend/auth/login.php'; 
            
            // Stop further JS execution (Security Best Practice)
            document.body.style.display = 'none'; 
            throw new Error('Halting execution due to auth failure');
        }

    })();
</script>
