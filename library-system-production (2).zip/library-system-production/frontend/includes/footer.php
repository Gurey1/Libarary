    </div>
    <!-- /#wrapper -->

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Core API & Auth Scripts -->
    <script src="../js/api.js"></script>
    <script>
       // Global Logout Handler
       const logoutBtn = document.getElementById('logout-btn');
       if(logoutBtn) {
           logoutBtn.addEventListener('click', (e) => {
               e.preventDefault();
               if(confirm('Are you sure you want to logout?')) {
                   API.logout();
               }
           });
       }
    </script>
</body>
</html>
