<!-- Sidebar -->
<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="bg-dark text-white border-end" id="sidebar-wrapper" style="width: 250px; min-height: 100vh;">
    <div class="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom">
        <i class="fas fa-book-reader me-2"></i> LMS
    </div>
    <div class="list-group list-group-flush my-3">
        <a href="index.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
        </a>
        <a href="users.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'users.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-users me-2"></i>Users
        </a>
        <a href="books.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'books.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-book me-2"></i>Books
        </a>
        <a href="borrowings.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'borrowings.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-exchange-alt me-2"></i>Borrowings
        </a>
        <a href="fines.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'fines.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-money-bill-wave me-2"></i>Fines
        </a>
        <a href="reports.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'reports.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-chart-line me-2"></i>Reports
        </a>
        <a href="audit-logs.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'audit-logs.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-history me-2"></i>Audit Logs
        </a>
        <a href="settings.php" class="list-group-item list-group-item-action bg-transparent text-white <?php echo ($current_page == 'settings.php') ? 'active-link' : ''; ?>">
            <i class="fas fa-cog me-2"></i>Settings
        </a>
        <a href="#" class="list-group-item list-group-item-action bg-transparent text-danger mt-3 fw-bold" id="logout-btn">
            <i class="fas fa-power-off me-2"></i>Logout
        </a>
    </div>
</div>

<style>
    /* Add simple active link style if not in global css usually */
    .active-link {
        font-weight: bold;
        background-color: rgba(255, 255, 255, 0.1) !important;
        border-left: 4px solid #0d6efd;
    }
</style>
