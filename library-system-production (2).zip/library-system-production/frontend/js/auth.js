document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
});

async function handleLogin(e) {
    e.preventDefault();

    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const loginBtn = document.getElementById('login-btn');
    const spinner = document.getElementById('loading-spinner');
    const errorAlert = document.getElementById('error-alert');
    const errorMsg = document.getElementById('error-msg');

    // Reset UI
    errorAlert.classList.add('d-none');
    loginBtn.disabled = true;
    spinner.classList.remove('d-none');
    loginBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Signing in...';

    const credentials = {
        email: emailInput.value.trim(),
        password: passwordInput.value
    };

    try {
        // Use the centralized API handler
        const res = await API.request('/auth/login', 'POST', credentials);

        // Check response structure
        if (res && res.status === 200 && res.data && res.data.status === 'success') {
            // 1. Store Token
            localStorage.setItem('token', res.data.data.access_token);
            localStorage.setItem('role', res.data.data.user.role_id || 'admin'); // Store role for UI logic
            localStorage.setItem('user', JSON.stringify(res.data.data.user));

            // 2. Redirect
            window.location.href = '../dashboard/index.php';
        } else {
            // Extract error message safely
            let message = 'Invalid credentials. Please try again.';
            if (res && res.data && res.data.message) {
                message = res.data.message;
            } else if (res && res.error) {
                message = res.error; // API helper might return this on network fail
            }

            throw new Error(message);
        }
    } catch (error) {
        console.error('Login Error:', error);
        errorMsg.textContent = error.message;
        errorAlert.classList.remove('d-none');

        // Reset Button
        loginBtn.disabled = false;
        loginBtn.innerHTML = 'Sign In';
        spinner.classList.add('d-none');
    }
}