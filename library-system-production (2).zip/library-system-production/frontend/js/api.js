const API_BASE_URL = '/library-system/backend/public/index.php/v1';

const API = {
    // Helper for fetch with auth headers
    request: async (endpoint, method = 'GET', body = null) => {
        const token = localStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        };
        if (token) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        const config = {
            method,
            headers
        };

        if (body) {
            config.body = JSON.stringify(body);
        }

        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`, config);

            // Handle 401 Unauthorized (Token expired)
            if (response.status === 401) {
                alert("Session expired. Please login again.");
                localStorage.removeItem('token');
                localStorage.removeItem('user_role');
                window.location.href = '/library-system/frontend/auth/login.php';
                return null;
            }

            // Try to parse JSON, but handle cases where it's not valid JSON
            let data;
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.indexOf('application/json') !== -1) {
                data = await response.json();
            } else {
                // If response is not JSON, get text content
                const text = await response.text();
                data = {
                    status: 'error',
                    message: 'Server error: ' + text.substring(0, 200) + (text.length > 200 ? '...' : '')
                };
            }

            return { status: response.status, data };
        } catch (error) {
            console.error('API Error:', error);
            return { status: 500, data: { status: 'error', message: 'Network Error or Server Unreachable' } };
        }
    },

    // Auth
    login: async (username, password) => {
        return await API.request('/auth/login', 'POST', { username, password });
    },

    logout: async () => {
        // Optional: call backend logout to kill refresh token
        await API.request('/auth/logout', 'POST');
        localStorage.removeItem('token');
        localStorage.removeItem('user_role');
        window.location.href = '/library-system/frontend/auth/login.php';
    },

    checkAuth: () => {
        if (!localStorage.getItem('token')) {
            window.location.href = '/library-system/frontend/auth/login.php';
        }
    }
};