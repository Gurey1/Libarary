document.addEventListener('DOMContentLoaded', () => {
    loadDashboardData();
});

async function loadDashboardData() {
    try {
        // Fetch Summary Stats
        const summaryRes = await API.request('/dashboard/summary');

        if (summaryRes && summaryRes.status === 200) {
            const data = summaryRes.data.data; // Response::success wraps data in 'data' key, and Report::overview returns data object directly or nested? Let's check ReportController.
            // ReportController::overview uses Report::getSummary()
            // Let's assume the structure is { total_books: X, ... } based on typical Report model

            // Actually, looking at ReportController.php line 14:
            // 'summary' => $report->getSummary(),
            // So data structure is { summary: {...}, most_borrowed: [...], ... }

            const summary = data.summary;

            animateValue("kpi-books", summary.total_books || 0);
            animateValue("kpi-borrowed", summary.total_borrowed || 0); // Check exact key from Report model
            animateValue("kpi-users", summary.total_users || 0);
            animateValue("kpi-fines", summary.total_fines || 0);
        }

        // Fetch Charts Data
        // 1. Monthly Borrowings
        const borrowingRes = await API.request('/reports/borrowings');
        if (borrowingRes && borrowingRes.status === 200) {
            initBorrowChart(borrowingRes.data.data);
        }

        // 2. Books by Category
        const booksRes = await API.request('/reports/books');
        if (booksRes && booksRes.status === 200 && booksRes.data.data.by_category) {
            initCategoryChart(booksRes.data.data.by_category);
        }

    } catch (error) {
        console.error("Dashboard Load Error:", error);
    }
}

function animateValue(id, value) {
    const element = document.getElementById(id);
    if (!element) return;
    element.innerText = value;
}

function initBorrowChart(data) {
    const ctx = document.getElementById('borrowChart');
    if (!ctx) return;

    // Data Format: [{month: '2023-11', count: 5}, ...]
    const labels = data.map(d => d.month);
    const values = data.map(d => d.count);

    if (window.borrowChartInstance) window.borrowChartInstance.destroy();

    window.borrowChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Monthly Borrowings',
                data: values,
                backgroundColor: '#0d6efd',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, ticks: { precision: 0 } }
            }
        }
    });
}

function initCategoryChart(data) {
    const ctx = document.getElementById('categoryChart');
    if (!ctx) return;

    // Data Format: [{name: 'Fiction', count: 10}, ...]
    const labels = data.map(d => d.name || 'Uncategorized');
    const values = data.map(d => d.count);
    const colors = ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#6610f2', '#fd7e14'];

    if (window.catChartInstance) window.catChartInstance.destroy();

    window.catChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: colors.slice(0, values.length)
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}
