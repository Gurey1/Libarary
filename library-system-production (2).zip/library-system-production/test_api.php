<?php
// Simple CLI test script to verify endpoints using cURL
$baseUrl = 'http://localhost/library-system/routes/api.php';

function makeRequest($url, $method, $data = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    }
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $httpCode, 'body' => json_decode($response, true)];
}

echo "Testing Book Module API...\n\n";

// 1. Create a Book
echo "1. Creating a book...\n";
$newBook = [
    'title' => 'Test PHP Book',
    'author' => 'John Doe',
    'category' => 'Technology',
    'isbn' => '1234567890',
    'published_year' => '2024',
    'total_copies' => 10,
    'available_copies' => 10
];
$resp = makeRequest("$baseUrl/books", 'POST', $newBook);
echo "Status: " . $resp['code'] . "\n";
print_r($resp['body']);
echo "\n";

// 2. Get all books
echo "2. Getting all books...\n";
$resp = makeRequest("$baseUrl/books", 'GET');
echo "Status: " . $resp['code'] . "\n";
// print_r($resp['body']); // Uncomment to see all data
echo "Count: " . (isset($resp['body']['data']) ? count($resp['body']['data']) : 0) . "\n\n";

// Get ID of the last created book (assuming it's the first in the list due to DESC order)
$bookId = isset($resp['body']['data'][0]['id']) ? $resp['body']['data'][0]['id'] : null;

if ($bookId) {
    // 3. Get Book by ID
    echo "3. Getting book by ID ($bookId)...\n";
    $resp = makeRequest("$baseUrl/books?id=$bookId", 'GET');
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";

    // 4. Update Book
    echo "4. Updating book ($bookId)...\n";
    $updateData = $newBook;
    $updateData['title'] = 'Updated Test PHP Book';
    $resp = makeRequest("$baseUrl/books?id=$bookId", 'PUT', $updateData);
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";

    // 5. Search by Title
    echo "5. Searching by title 'Updated'...\n";
    $resp = makeRequest("$baseUrl/books/search/title?value=Updated", 'GET');
    echo "Status: " . $resp['code'] . "\n";
    echo "Matches: " . count($resp['body']['data']) . "\n\n";

     // 6. Search by Author
     echo "6. Searching by author 'John'...\n";
     $resp = makeRequest("$baseUrl/books/search/author?value=John", 'GET');
     echo "Status: " . $resp['code'] . "\n";
     echo "Matches: " . count($resp['body']['data']) . "\n\n";

    // 7. Delete Book
    echo "7. Deleting book ($bookId)...\n";
    $resp = makeRequest("$baseUrl/books?id=$bookId", 'DELETE');
    echo "Status: " . $resp['code'] . "\n";
    print_r($resp['body']);
    echo "\n";
} else {
    echo "Could not retrieve book ID for further tests.\n";
}
