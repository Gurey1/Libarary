<?php
// Database initialization script
header('Content-Type: text/plain');

echo "Initializing Library Management System Database...\n\n";

try {
    // Create database connection without specifying dbname first
    $host = "localhost";
    $username = "root";
    $password = "";
    
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS library_db");
    echo "✓ Database 'library_db' created successfully or already exists.\n";
    
    // Select the database
    $pdo->exec("USE library_db");
    
    // Read and execute the setup.sql file
    $sql = file_get_contents('setup.sql');
    
    // Split the SQL file into individual statements
    $statements = explode(';', $sql);
    
    $successCount = 0;
    $errorCount = 0;
    
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (!empty($statement)) {
            try {
                $pdo->exec($statement);
                $successCount++;
            } catch (PDOException $e) {
                // Skip errors for duplicate keys, etc.
                $errorCount++;
            }
        }
    }
    
    echo "✓ Executed $successCount SQL statements successfully.\n";
    echo "✓ Database schema and seed data installed.\n\n";
    echo "You can now try logging in with:\n";
    echo "Username: admin\n";
    echo "Password: admin123\n";
    
} catch (PDOException $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "Please check your MySQL server configuration.\n";
}
?>