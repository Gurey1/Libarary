<?php
require_once "../config/database.php";

try {
    $db = Database::getInstance();
    if ($db) {
        echo "Database connected successfully!";
    } else {
        echo "Connection failed!";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
