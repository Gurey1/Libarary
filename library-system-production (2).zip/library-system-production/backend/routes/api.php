<?php

// Central Entry Point for API v1
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable HTML error output
ini_set('log_errors', 1);     // Ensure errors are logged instead

require_once __DIR__ . '/../helpers/Response.php';

// Controllers
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/BookController.php';
require_once __DIR__ . '/../controllers/BorrowController.php';
require_once __DIR__ . '/../controllers/FineController.php';
require_once __DIR__ . '/../controllers/NotificationController.php';
require_once __DIR__ . '/../controllers/ReportController.php';
require_once __DIR__ . '/../controllers/RoleController.php';
require_once __DIR__ . '/../controllers/PermissionController.php';
require_once __DIR__ . '/../controllers/AuditLogController.php';
require_once __DIR__ . '/../controllers/SettingController.php';
require_once __DIR__ . '/../controllers/UserController.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET,POST,PUT,DELETE,OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Basic Routing Logic
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', $uri);

// Expected URI: /library-system/api/v1/{resource}/{id}
// Adjust based on your server setup. Assuming localhost/library-system/api/v1/...
// $uri[0] = ''
// $uri[1] = 'library-system'
// $uri[2] = 'api'
// $uri[3] = 'v1'
// $uri[4] = 'resource' (auth, books, etc)
// $uri[5] = 'id' or action

// Find position of 'v1' to make it robust
$key = array_search('v1', $uri);
if ($key === false) {
    Response::notFound("API Version not specified or incorrect URL structure");
}

$resource = $uri[$key + 1] ?? null;
$id = $uri[$key + 2] ?? null;

$method = $_SERVER['REQUEST_METHOD'];

// Dispatcher
switch ($resource) {
    case 'auth':
        $controller = new AuthController();
        if ($id === 'login' && $method === 'POST') $controller->login();
        elseif ($id === 'refresh' && $method === 'POST') $controller->refresh();
        elseif ($id === 'logout' && $method === 'POST') $controller->logout();
        else Response::notFound("Auth route not found");
        break;

    case 'books':
        $controller = new BookController();
        if ($method === 'GET') {
            if ($id) $controller->show($id);
            else $controller->index();
        } elseif ($method === 'POST') {
             // Check if it's a restore action: /books/{id}/restore
             $action = $uri[$key + 3] ?? null; // /v1/books/1/restore
             if ($id && $action === 'restore') {
                 $controller->restore($id);
             } else {
                 $controller->store();
             }
        } elseif ($method === 'PUT' && $id) {
            $controller->update($id);
        } elseif ($method === 'DELETE' && $id) {
            $controller->destroy($id);
        } else {
            Response::error("Method not allowed for Books", 405);
        }
        break;

    case 'borrow':
        $controller = new BorrowController();
        if ($method === 'POST') $controller->borrow();
        else Response::error("Method not allowed", 405);
        break;
        
    case 'return':
        $controller = new BorrowController();
        if ($method === 'POST') $controller->returnBook();
        else Response::error("Method not allowed", 405);
        break;
        
    case 'transactions':
        $controller = new BorrowController();
        if ($method === 'GET') {
            if ($uri[$key + 2] === 'user' && isset($uri[$key + 3])) {
                 // /transactions/user/{id}
                 $controller->userHistory($uri[$key + 3]);
            } else {
                 $controller->history();
            }
        }
        else Response::error("Method not allowed", 405);
        break;

    case 'fines':
        $controller = new FineController();
        if ($method === 'GET') {
            if ($uri[$key + 2] === 'user' && isset($uri[$key + 3])) {
                 // /fines/user/{id}
                 $controller->userFines($uri[$key + 3]);
            } else {
                 // /fines
                 $controller->index();
            }
        }
        elseif ($method === 'POST') {
             // /fines/pay/{id}
             if ($uri[$key + 2] === 'pay' && isset($uri[$key + 3])) {
                 $controller->pay($uri[$key + 3]);
             } else {
                 Response::notFound("Fine route not found");
             }
        }
        else Response::error("Method not allowed", 405);
        break;

    case 'notifications':
        $controller = new NotificationController();
        if ($method === 'GET') $controller->index();
        else Response::error("Method not allowed", 405);
        break;
        
    case 'reports':
        $controller = new ReportController();
        if ($method === 'GET') {
            if (isset($uri[$key + 2])) {
                $sub = $uri[$key + 2];
                if ($sub === 'overview') $controller->overview();
                elseif ($sub === 'books') $controller->books();
                elseif ($sub === 'borrowings') $controller->borrowings();
                elseif ($sub === 'fines') $controller->fines();
                elseif ($sub === 'users') $controller->users();
                else Response::notFound("Report type not found");
            } else {
                 $controller->overview();
            }
        }
        else Response::error("Method not allowed", 405);
        break;

    case 'dashboard':
        // Handle /dashboard/summary for KPI cards
        if ($id === 'summary' && $method === 'GET') {
            $controller = new ReportController();
            $controller->overview();
        } else {
             Response::notFound("Dashboard route not found");
        }
        break;

    case 'audit-logs':
        $controller = new AuditLogController();
        if ($method === 'GET') {
             if ($uri[$key + 2] === 'admin' && isset($uri[$key + 3])) {
                 $controller->adminLogs($uri[$key + 3]);
             } else {
                 $controller->index();
             }
        }
        else Response::error("Method not allowed", 405);
        break;
        
    case 'settings':
        $controller = new SettingController();
        if ($method === 'GET') $controller->index();
        elseif ($method === 'POST') {
             // /settings/update
             if ($uri[$key + 2] === 'update') $controller->update();
             else Response::notFound("Setting route not found");
        }
        else Response::error("Method not allowed", 405);
        break;

    case 'roles':
        $controller = new RoleController();
        if ($method === 'GET') $controller->index();
        elseif ($method === 'POST') {
             // /roles/create or /roles/assign-permission
             // Actually standard REST would be /roles (create) or /roles/{id}/permissions (assign)
             // But prompt asked specifically for: /api/v1/roles/create, /api/v1/roles/assign-permission
             // My router logic parses ID as index 2.
             // If URL is /api/v1/roles/create, $id is 'create'.
             if ($id === 'create') $controller->create();
             elseif ($id === 'assign-permission') $controller->assignPermission();
             else Response::notFound("Role route not found");
        }
        else Response::error("Method not allowed", 405);
        break;

    case 'permissions':
        $controller = new PermissionController();
        if ($method === 'GET') $controller->index();
        elseif ($method === 'POST') {
             if ($id === 'create') $controller->create();
             else Response::notFound("Permission route not found");
        }
        else Response::error("Method not allowed", 405);
        break;

    case 'users':
        $controller = new UserController();
        if ($method === 'GET') $controller->index();
        elseif ($method === 'POST') $controller->store();
        elseif ($method === 'PUT' && $id) $controller->update($id);
        elseif ($method === 'PATCH' && $id) {
             // /users/{id}/status
             if ($uri[$key + 3] === 'status') $controller->updateStatus($id);
             else Response::notFound("User route not found");
        }
        else Response::error("Method not allowed", 405);
        break;

    default:
        Response::notFound("Endpoint not found: $resource");
        break;
}
