<?php

require_once __DIR__ . '/../helpers/JWT.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Permission.php';

class AuthMiddleware {
    
    public static function authenticate() {
        $headers = getallheaders();
        $authHeader = $headers['Authorization'] ?? '';
        
        if (!preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
            Response::unauthorized("Token not provided");
            exit; // Just to be safe, though Response::unauthorized exits.
        }
        
        $token = $matches[1];
        $payload = JWT::verify($token);
        
        if (!$payload) {
            Response::unauthorized("Invalid or expired token");
        }
        
        return $payload; // Returns user data (id, username, etc.)
    }

    public static function authorize($permission) {
        $user = self::authenticate(); // Enforce login first
        
        if (!Permission::check($user['sub'], $permission)) {
            Response::forbidden("You do not have permission: $permission");
        }
        
        return $user;
    }
}
