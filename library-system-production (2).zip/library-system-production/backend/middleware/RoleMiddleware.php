<?php

require_once __DIR__ . '/../middleware/AuthMiddleware.php';
require_once __DIR__ . '/../models/Permission.php';
require_once __DIR__ . '/../helpers/Response.php';

class RoleMiddleware {
    
    /**
     * Checks if the authenticated user has the required permission.
     * Uses AuthMiddleware to get the user context first.
     */
    public static function hasPermission($permissionName) {
        // 1. Validate Token & Get User
        $user = AuthMiddleware::authenticate();
        
        // 2. Check Permission in Database
        if (!Permission::check($user['sub'], $permissionName)) {
            Response::forbidden("Access Denied: Missing permission '$permissionName'");
        }
        
        return $user;
    }
}
