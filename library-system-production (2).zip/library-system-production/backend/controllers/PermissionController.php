<?php

require_once __DIR__ . '/../models/Permission.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Validator.php';
require_once __DIR__ . '/../models/AuditLog.php';

class PermissionController {
    
    public function index() {
        RoleMiddleware::hasPermission('manage_users');
        $model = new Permission();
        Response::success($model->getAll());
    }
    
    public function create() {
        $user = RoleMiddleware::hasPermission('manage_users');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $errors = Validator::validate($data, ['name' => 'required']);
        if ($errors) Response::error("Validation Error", 400, $errors);
        
        $model = new Permission();
        $id = $model->create($data['name']);
        
        if ($id) {
            AuditLog::log($user['sub'], 'PERMISSION_CREATED', "Permission created: {$data['name']}");
            Response::success(['id' => $id], "Permission created successfully");
        } else {
            Response::error("Failed to create permission");
        }
    }
}
