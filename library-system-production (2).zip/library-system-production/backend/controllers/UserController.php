<?php

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Validator.php';

class UserController {
    
    public function index() {
        RoleMiddleware::hasPermission('manage_users');
        $model = new User();
        Response::success($model->getAll());
    }
    
    public function store() {
        $admin = RoleMiddleware::hasPermission('manage_users');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $errors = Validator::validate($data, ['full_name' => 'required', 'email' => 'required|email']);
        if ($errors) Response::error("Validation Error", 400, $errors);
        
        $model = new User();
        $id = $model->create($data);
        
        if ($id) {
            // Log action...
            Response::success(['id' => $id], "User created successfully");
        } else {
            Response::error("Failed to create user (Email might be duplicate)");
        }
    }
    
    public function update($id) {
        RoleMiddleware::hasPermission('manage_users');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $model = new User();
        if ($model->update($id, $data)) {
            Response::success([], "User updated successfully");
        } else {
            Response::error("Failed to update user");
        }
    }
    
    public function updateStatus($id) {
        RoleMiddleware::hasPermission('manage_users');
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!isset($data['status']) || !in_array($data['status'], ['Active', 'Suspended'])) {
             Response::error("Invalid Status", 400);
        }
        
        $model = new User();
        if ($model->update($id, ['status' => $data['status']])) {
            Response::success([], "User status updated");
        } else {
            Response::error("Failed to update status");
        }
    }
}
