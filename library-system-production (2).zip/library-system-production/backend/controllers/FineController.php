<?php

require_once __DIR__ . '/../models/Fine.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../models/AuditLog.php';

class FineController {
    
    public function index() {
        RoleMiddleware::hasPermission('view_fines');
        $fineModel = new Fine();
        $fines = $fineModel->getAll();
        Response::success($fines);
    }
    
    public function userFines($userId) {
        RoleMiddleware::hasPermission('view_fines');
        $fineModel = new Fine();
        $fines = $fineModel->getAll($userId);
        Response::success($fines);
    }
    
    public function pay($id) {
        $admin = RoleMiddleware::hasPermission('pay_fine');
        
        $fineModel = new Fine();
        if ($fineModel->pay($id)) {
            AuditLog::log($admin['sub'], 'FINE_PAID', "Fine ID $id marked as paid");
            Response::success([], "Fine paid successfully");
        } else {
            Response::error("Failed to pay fine");
        }
    }
}
