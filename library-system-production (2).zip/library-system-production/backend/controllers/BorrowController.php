<?php

require_once __DIR__ . '/../models/BorrowTransaction.php';
require_once __DIR__ . '/../models/Book.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Validator.php';
require_once __DIR__ . '/../models/AuditLog.php';

class BorrowController {
    
    public function borrow() {
        $admin = RoleMiddleware::hasPermission('borrow_book');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $errors = Validator::validate($data, [
            'user_id' => 'required|numeric',
            'book_id' => 'required|numeric',
            'days' => 'numeric' // Optional, default 14
        ]);
        if ($errors) Response::error("Validation Error", 400, $errors);
        
        $userModel = new User();
        // Check 1: User Active
        if (!$userModel->isActive($data['user_id'])) {
            Response::error("User is not active or does not exist", 400);
        }
        
        // Check 2: Unpaid Fines (New Rule)
        if ($userModel->hasUnpaidFines($data['user_id'])) {
            Response::error("User has unpaid fines. Borrowing blocked.", 403);
        }
        
        $bookModel = new Book();
        $book = $bookModel->getById($data['book_id']);
        if (!$book || $book['available_copies'] <= 0) {
            Response::error("Book not available", 400);
        }
        
        $transactionModel = new BorrowTransaction();
        if ($transactionModel->getActiveTransaction($data['user_id'], $data['book_id'])) {
             Response::error("User already has an active borrow for this book", 400);
        }
        
        // Calculate Due Date using Settings
        require_once __DIR__ . '/../models/Setting.php';
        $settingModel = new Setting();
        
        // Use 'days' from input if provided, else use system setting
        $defaultDays = $settingModel->get('borrow_days_limit', 14);
        $days = $data['days'] ?? $defaultDays;
        
        // Also check max books limit
        $maxBooks = $settingModel->get('max_books_per_user', 5);
        $currentBorrows = $db->query("SELECT COUNT(*) FROM borrow_transactions WHERE user_id = {$data['user_id']} AND status = 'borrowed'")->fetchColumn();
        if ($currentBorrows >= $maxBooks) {
             Response::error("User has reached maximum borrow limit ($maxBooks)", 403);
        }

        $dueDate = date('Y-m-d', strtotime("+$days days"));
        
        // Transaction
        try {
            $db->beginTransaction();
            
            $transactionModel->create($data['user_id'], $data['book_id'], $dueDate);
            $db->exec("UPDATE books SET available_copies = available_copies - 1 WHERE id = {$data['book_id']}");
            
            $db->commit();
            
            // Use Enhanced Logger
            require_once __DIR__ . '/../helpers/Logger.php';
            Logger::info($admin['sub'], 'BORROW_BOOK', "User {$data['user_id']} borrowed book {$data['book_id']}", 'borrow_transaction', $data['book_id']); // Linking to book as entity mostly
            
            Response::success([], "Book borrowed successfully");
            
        } catch (Exception $e) {
            $db->rollBack();
            Response::error("Borrow Failed: " . $e->getMessage());
        }
    }
    
    public function returnBook() {
        $admin = RoleMiddleware::hasPermission('return_book');
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (empty($data['transaction_id'])) {
             Response::error("Transaction ID required", 400);
        }
        
        $transactionModel = new BorrowTransaction();
        $record = $transactionModel->getById($data['transaction_id']);
        
        if (!$record || $record['status'] !== 'borrowed') {
             Response::error("Invalid transaction or already returned", 400);
        }
        
        $today = date('Y-m-d');
        // Logic: Compare today with due_date
        $isLate = ($today > $record['due_date']);
        $status = $isLate ? 'late' : 'returned';
        
        $fineAmount = 0;
        $daysLate = 0;
        
        if ($isLate) {
            $diff = strtotime($today) - strtotime($record['due_date']);
            $daysLate = ceil($diff / (60 * 60 * 24));
            
            require_once __DIR__ . '/../models/Setting.php';
            $settingModel = new Setting();
            $finePerDay = $settingModel->get('fine_per_day', 1.00);
            
            $fineAmount = $daysLate * $finePerDay; 
        }
        
        $db = Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Mark Transaction Returned
            $transactionModel->markReturned($record['id'], $today, $status);
            
            // Update Book Stock
            $db->exec("UPDATE books SET available_copies = available_copies + 1 WHERE id = {$record['book_id']}");
            
            // Create Fine if Late
            if ($isLate && $fineAmount > 0) {
                // We need to require Fine model first
                require_once __DIR__ . '/../models/Fine.php';
                $fineModel = new Fine();
                // create($userId, $transactionId, $daysLate, $amount)
                $fineModel->create($record['user_id'], $record['id'], $daysLate, $fineAmount);
            }
            
            $db->commit();
            
            $msg = "Book returned successfully";
            if ($isLate) $msg .= ". Late Return: Fine of $$fineAmount generated ($daysLate days late).";
            
            require_once __DIR__ . '/../helpers/Logger.php';
            $entity = 'borrow_transaction';
            Logger::info($admin['sub'], 'RETURN_BOOK', "Transaction {$record['id']} returned ($status)", $entity, $record['id']);

            Response::success(['fine_amount' => $fineAmount], $msg);
            
        } catch (Exception $e) {
            $db->rollBack();
            Response::error("Return Failed: " . $e->getMessage());
        }
    }
    
    public function history() {
        RoleMiddleware::hasPermission('view_transactions');
        $userId = $_GET['user_id'] ?? null;
        
        $transactionModel = new BorrowTransaction();
        $history = $transactionModel->getHistory($userId ? ['user_id' => $userId] : []);
        
        Response::success($history);
    }
    
    public function userHistory($id) {
        RoleMiddleware::hasPermission('view_transactions');
        $transactionModel = new BorrowTransaction();
        $history = $transactionModel->getHistory(['user_id' => $id]);
        Response::success($history);
    }
}
