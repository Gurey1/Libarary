<?php
include_once '../config/database.php';
include_once '../models/Member.php';

class MemberController {
    private $db;
    private $member;

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
        $this->member = new Member($this->db);
    }

    // Helper to send JSON response
    private function sendResponse($status, $message, $data = []) {
        header('Content-Type: application/json');
        http_response_code($status == 'success' ? 200 : 400); 
        echo json_encode([
            "status" => $status,
            "message" => $message,
            "data" => $data
        ]);
        exit;
    }

    public function getAllMembers() {
        $stmt = $this->member->getAll();
        $members_arr = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            array_push($members_arr, $row);
        }
        $this->sendResponse("success", "Members retrieved successfully", $members_arr);
    }

    public function getMemberById($id) {
        $stmt = $this->member->getById($id);
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->sendResponse("success", "Member retrieved successfully", $row);
        } else {
            $this->sendResponse("error", "Member not found");
        }
    }

    public function createMember() {
        $data = json_decode(file_get_contents("php://input"));

        // Validation
        if (!empty($data->name) && !empty($data->email)) {
            
            // Check email uniqueness
            if ($this->member->emailExists($data->email)) {
                $this->sendResponse("error", "Email already exists");
            }

            // Simple phone validation (can be more complex)
            if (!empty($data->phone) && !preg_match('/^[0-9\-\+\(\)\s]*$/', $data->phone)) {
                 $this->sendResponse("error", "Invalid phone info");
            }

            $this->member->name = $data->name;
            $this->member->email = $data->email;
            $this->member->phone = isset($data->phone) ? $data->phone : null;

            if ($this->member->create()) {
                $this->sendResponse("success", "Member created successfully");
            } else {
                $this->sendResponse("error", "Unable to create member");
            }
        } else {
            $this->sendResponse("error", "Name and Email are required");
        }
    }

    public function updateMember($id) {
        $data = json_decode(file_get_contents("php://input"));

        if (!empty($data->name) && !empty($data->email)) {
             // Check email uniqueness excluding current member
             if ($this->member->emailExists($data->email, $id)) {
                $this->sendResponse("error", "Email already exists");
            }

             $this->member->name = $data->name;
             $this->member->email = $data->email;
             $this->member->phone = isset($data->phone) ? $data->phone : null;

             if ($this->member->update($id)) {
                 $this->sendResponse("success", "Member updated successfully");
             } else {
                 $this->sendResponse("error", "Unable to update member");
             }
        } else {
            $this->sendResponse("error", "Name and Email are required");
        }
    }

    public function deleteMember($id) {
        // Check active borrows is handled in model
        if ($this->member->delete($id)) {
             $this->sendResponse("success", "Member deleted successfully");
        } else {
             // If delete failed, it might be due to active borrows or simple error
             // We can check explicitly to give better error message or just rely on generic
             if ($this->member->hasActiveBorrows($id)) {
                 $this->sendResponse("error", "Cannot delete member with active borrow records");
             }
             $this->sendResponse("error", "Unable to delete member");
        }
    }

    public function getBorrowHistory($id) {
        $stmt = $this->member->getBorrowHistory($id);
        $history_arr = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            array_push($history_arr, $row);
        }
        $this->sendResponse("success", "Member borrow history retrieved", $history_arr);
    }
}
