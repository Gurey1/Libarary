<?php
include_once '../config/database.php';
include_once '../models/Admin.php';
include_once '../helpers/Auth.php';
include_once '../helpers/Response.php';

class AdminController {
    private $db;
    private $admin;

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
        $this->admin = new Admin($this->db);
    }

    // Admin Login
    public function login() {
        $data = json_decode(file_get_contents("php://input"));

        if (!empty($data->username) && !empty($data->password)) {
            if ($this->admin->login($data->username, $data->password)) {
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['admin_id'] = $this->admin->id;
                $_SESSION['username'] = $this->admin->username;

                Response::send([
                    "id" => $this->admin->id,
                    "username" => $this->admin->username
                ], "Login successful");
            } else {
                Response::error("Invalid credentials", 401);
            }
        } else {
            Response::error("Username and password required", 400);
        }
    }

    // Admin Logout
    public function logout() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        session_unset();
        session_destroy();

        Response::send([], "Logged out successfully");
    }

    // Get Admin Profile
    public function profile() {
        Auth::requireAuth(); // Verify login

        Response::send([
            "id" => $_SESSION['admin_id'],
            "username" => $_SESSION['username']
        ], "Profile retrieved successfully");
    }
}
