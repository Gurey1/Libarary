<?php

require_once __DIR__ . '/../models/Notification.php';
require_once __DIR__ . '/../middleware/AuthMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';

class NotificationController {
    
    public function index() {
        AuthMiddleware::authenticate();
        $notif = new Notification();
        $list = $notif->getAll();
        Response::success($list);
    }
}
