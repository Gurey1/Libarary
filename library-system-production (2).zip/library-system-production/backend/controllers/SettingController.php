<?php

require_once __DIR__ . '/../models/Setting.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../models/AuditLog.php'; // Will need to update AuditLog usage later

class SettingController {
    
    public function index() {
        RoleMiddleware::hasPermission('manage_settings');
        $model = new Setting();
        Response::success($model->getAll());
    }
    
    public function update() {
        $admin = RoleMiddleware::hasPermission('manage_settings');
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (empty($data['settings']) || !is_array($data['settings'])) {
            Response::error("Invalid payload", 400);
        }
        
        $model = new Setting();
        $db = Database::getInstance();
        $db->beginTransaction();
        
        try {
            foreach ($data['settings'] as $key => $value) {
                $model->update($key, $value);
            }
            $db->commit();
            
            // Log Action (Using legacy AuditLog for now, will upgrade next)
            AuditLog::log($admin['sub'], 'SETTINGS_UPDATE', "Updated settings: " . implode(', ', array_keys($data['settings'])));
            
            Response::success([], "Settings updated successfully");
        } catch (Exception $e) {
            $db->rollBack();
            Response::error("Update failed: " . $e->getMessage());
        }
    }
}
