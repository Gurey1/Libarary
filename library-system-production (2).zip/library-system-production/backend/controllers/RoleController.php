<?php

require_once __DIR__ . '/../models/Role.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Validator.php';
require_once __DIR__ . '/../models/AuditLog.php';

class RoleController {
    
    public function index() {
        RoleMiddleware::hasPermission('manage_users'); // Protect
        $roleModel = new Role();
        Response::success($roleModel->getAll());
    }
    
    public function create() {
        $user = RoleMiddleware::hasPermission('manage_users');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $errors = Validator::validate($data, ['name' => 'required']);
        if ($errors) Response::error("Validation Error", 400, $errors);
        
        $roleModel = new Role();
        $id = $roleModel->create($data['name']);
        
        if ($id) {
            AuditLog::log($user['sub'], 'ROLE_CREATED', "Role created: {$data['name']}");
            Response::success(['id' => $id], "Role created successfully");
        } else {
            Response::error("Failed to create role");
        }
    }
    
    public function assignPermission() {
        $user = RoleMiddleware::hasPermission('manage_users');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $errors = Validator::validate($data, ['role_id' => 'required|numeric', 'permission_id' => 'required|numeric']);
        if ($errors) Response::error("Validation Error", 400, $errors);
        
        $roleModel = new Role();
        if ($roleModel->assignPermission($data['role_id'], $data['permission_id'])) {
            AuditLog::log($user['sub'], 'PERMISSION_ASSIGNED', "Perm {$data['permission_id']} to Role {$data['role_id']}");
            Response::success([], "Permission assigned successfully");
        } else {
            Response::error("Failed to assign permission");
        }
    }
}
