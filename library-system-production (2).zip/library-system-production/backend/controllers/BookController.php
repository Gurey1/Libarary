<?php

require_once __DIR__ . '/../models/Book.php';
require_once __DIR__ . '/../middleware/AuthMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Validator.php';
require_once __DIR__ . '/../models/AuditLog.php';

class BookController {
    
    public function index() {
        AuthMiddleware::authenticate(); // Protect route generally
        $filters = [
            'search' => $_GET['search'] ?? null,
            'category' => $_GET['category'] ?? null,
            'tag' => $_GET['tag'] ?? null
        ];
        
        $book = new Book();
        $books = $book->getAll($filters);
        Response::success($books);
    }
    
    public function show($id) {
        AuthMiddleware::authenticate();
        $bookModel = new Book();
        $book = $bookModel->getById($id);
        
        if ($book) {
            Response::success($book);
        } else {
            Response::notFound("Book not found");
        }
    }
    
    public function store() {
        $user = AuthMiddleware::authorize('book_create');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $errors = Validator::validate($data, [
            'title' => 'required',
            'author' => 'required',
            'isbn' => 'required',
            'total_copies' => 'required|numeric'
        ]);
        
        if (!empty($errors)) {
            Response::error("Validation Failed", 400, $errors);
        }
        
        $bookModel = new Book();
        $bookId = $bookModel->create($data);
        
        if ($bookId) {
            if (isset($data['category_ids'])) {
                $bookModel->attachCategories($bookId, $data['category_ids']);
            }
            if (isset($data['tag_ids'])) {
                $bookModel->attachTags($bookId, $data['tag_ids']);
            }
            
            AuditLog::log($user['sub'], 'BOOK_CREATED', "Created book ID: $bookId");
            Response::success(['id' => $bookId], "Book created successfully");
        } else {
            Response::error("Failed to create book");
        }
    }
    
    public function update($id) {
        $user = AuthMiddleware::authorize('book_update');
        $data = json_decode(file_get_contents("php://input"), true);
        
        $bookModel = new Book();
        if ($bookModel->update($id, $data)) {
            AuditLog::log($user['sub'], 'BOOK_UPDATED', "Updated book ID: $id");
            Response::success([], "Book updated successfully");
        } else {
            Response::error("Failed to update book");
        }
    }
    
    public function destroy($id) {
        $user = AuthMiddleware::authorize('book_delete');
        $bookModel = new Book();
        if ($bookModel->softDelete($id)) {
             AuditLog::log($user['sub'], 'BOOK_DELETED', "Soft deleted book ID: $id");
             Response::success([], "Book deleted successfully");
        } else {
             Response::error("Failed to delete book");
        }
    }

    public function restore($id) {
        $user = AuthMiddleware::authorize('book_delete'); // Assuming same permission for restore
        $bookModel = new Book();
        if ($bookModel->restore($id)) {
             AuditLog::log($user['sub'], 'BOOK_RESTORED', "Restored book ID: $id");
             Response::success([], "Book restored successfully");
        } else {
             Response::error("Failed to restore book");
        }
    }
}
