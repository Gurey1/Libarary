<?php

require_once __DIR__ . '/../models/Admin.php';
require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../helpers/JWT.php';
require_once __DIR__ . '/../helpers/Response.php';
require_once __DIR__ . '/../helpers/Validator.php';

class AuthController {
    
    public function login() {
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (isset($data['email']) && !isset($data['username'])) {
            $data['username'] = $data['email'];
        }

        $errors = Validator::validate($data, [
            'username' => 'required',
            'password' => 'required'
        ]);

        if (!empty($errors)) {
            Response::error("Validation Failed", 400, $errors);
        }

        $adminModel = new Admin();
        $admin = $adminModel->login($data['username'], $data['password']);

        if ($admin) {
            // Generate Access Token (Short-lived, e.g., 1 hour)
            $accessTokenPayload = [
                'sub' => $admin['id'],
                'role' => $admin['role_id'],
                'exp' => time() + 3600 
            ];
            $accessToken = JWT::encode($accessTokenPayload);

            // Generate Refresh Token (Long-lived, e.g., 7 days)
            $refreshTokenPayload = [
                'sub' => $admin['id'],
                'type' => 'refresh',
                'exp' => time() + (7 * 24 * 3600)
            ];
            $refreshToken = JWT::encode($refreshTokenPayload);

            // Save Refresh Token
            $adminModel->saveRefreshToken($admin['id'], $refreshToken);
            
            // Log Action
            AuditLog::log($admin['id'], 'LOGIN', 'Admin logged in successfully');

            Response::success([
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'user' => [
                    'id' => $admin['id'],
                    'username' => $admin['username']
                ]
            ], "Login Successful");
        } else {
            Response::unauthorized("Invalid Credentials");
        }
    }

    public function refresh() {
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (!isset($data['refresh_token'])) {
            Response::error("Refresh Token Required", 400);
        }

        $adminModel = new Admin();
        // Verify token matches what's in DB (invalidation check)
        $admin = $adminModel->getByRefreshToken($data['refresh_token']);
        
        if (!$admin) {
            Response::unauthorized("Invalid Refresh Token");
        }
        
        // Verify JWT Validity
        $decoded = JWT::verify($data['refresh_token']);
        if (!$decoded || $decoded['type'] !== 'refresh') {
             Response::unauthorized("Invalid or Expired Refresh Token");
        }
        
        // Generate NEW Access Token
        $newAccessToken = JWT::encode([
            'sub' => $admin['id'],
            'role' => $admin['role_id'],
            'exp' => time() + 3600
        ]);
        
        Response::success(['access_token' => $newAccessToken], "Token Refreshed");
    }

    public function logout() {
        // We need the user ID. We can get it from the middleware-authenticated user if the route is protected, 
        // OR we can rely on the provided refresh token in body to identify user to clear.
        // A secure logout typically requires authentication first (access token).
        
        // Assuming this route is protected by AuthMiddleware::authenticate() in routes
        // We will fetch the user from the request context or AuthMiddleware call if possible, 
        // but cleaner is to rely on AuthMiddleware passing it. 
        // For strict MVC here without a router passing args, we might need to call AuthMiddleware manually or rely on header.
        
        // Let's assume standard flow: Client sends Bearer token.
        $user = AuthMiddleware::authenticate();
        
        $adminModel = new Admin();
        $adminModel->clearRefreshToken($user['sub']);
        
        AuditLog::log($user['sub'], 'LOGOUT', 'Admin logged out');
        
        Response::success([], "Logged out successfully");
    }
}
