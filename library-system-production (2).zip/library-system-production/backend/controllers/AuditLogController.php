<?php

require_once __DIR__ . '/../models/AuditLog.php';
require_once __DIR__ . '/../middleware/RoleMiddleware.php';
require_once __DIR__ . '/../helpers/Response.php';

class AuditLogController {
    
    public function index() {
        RoleMiddleware::hasPermission('view_audit_logs');
        $model = new AuditLog();
        Response::success($model->getAll());
    }
    
    public function adminLogs($adminId) {
        RoleMiddleware::hasPermission('view_audit_logs');
        $model = new AuditLog();
        Response::success($model->getAll($adminId));
    }
}
