<?php
class Auth {
    // Check if user is logged in
    public static function check() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if (isset($_SESSION['admin_id'])) {
            return true;
        }
        return false;
    }

    // Require Authentication Middleware
    public static function requireAuth() {
        if (!self::check()) {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Unauthorized access. Please login."]);
            exit();
        }
    }
}
