<?php

class Response {
    public static function json($status, $message, $data = [], $code = 200) {
        http_response_code($code);
        header('Content-Type: application/json');
        echo json_encode([
            "status" => $status, // "success" or "error"
            "message" => $message,
            "data" => $data
        ]);
        exit;
    }

    public static function success($data = [], $message = "Operation successful") {
        self::json("success", $message, $data, 200);
    }

    public static function error($message = "Operation failed", $code = 400, $errors = []) {
        self::json("error", $message, $errors, $code);
    }
    
    public static function unauthorized($message = "Unauthorized") {
        self::json("error", $message, [], 401);
    }
    
    public static function forbidden($message = "Access Denied") {
        self::json("error", $message, [], 403);
    }
    
    public static function notFound($message = "Resource not found") {
        self::json("error", $message, [], 404);
    }
}
