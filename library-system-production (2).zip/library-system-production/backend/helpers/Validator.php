<?php

class Validator {
    public static function validate(array $data, array $rules) {
        $errors = [];

        foreach ($rules as $field => $ruleString) {
            $ruleList = explode('|', $ruleString);
            
            foreach ($ruleList as $rule) {
                // Required
                if ($rule === 'required' && (!isset($data[$field]) || trim($data[$field]) === '')) {
                    $errors[$field][] = "$field is required.";
                }

                // Email
                if ($rule === 'email' && isset($data[$field]) && !filter_var($data[$field], FILTER_VALIDATE_EMAIL)) {
                    $errors[$field][] = "$field must be a valid email address.";
                }

                // Numeric
                if ($rule === 'numeric' && isset($data[$field]) && !is_numeric($data[$field])) {
                    $errors[$field][] = "$field must be a number.";
                }
                
                // Date format (basic)
                if ($rule === 'date' && isset($data[$field]) && !strtotime($data[$field])) {
                    $errors[$field][] = "$field must be a valid date.";
                }
            }
        }

        return $errors;
    }
}
