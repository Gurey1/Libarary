<?php

require_once __DIR__ . '/../config/database.php';

class Permission {
    public static function check($userId, $permissionSlug) {
        $db = Database::getInstance();
        
        // Super Admin Bypass (optional, but good for enterprise)
        // Check if user is super admin
        $stmt = $db->prepare("SELECT r.name FROM admins a JOIN roles r ON a.role_id = r.id WHERE a.id = ?");
        $stmt->execute([$userId]);
        $roleName = $stmt->fetchColumn();
        
        if ($roleName === 'Super Admin') {
            return true; 
        }

        // Check specific permission
        $query = "
            SELECT COUNT(*) 
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            JOIN admins a ON a.role_id = rp.role_id
            WHERE a.id = ? AND p.slug = ?
        ";
        $stmt = $db->prepare($query);
        $stmt->execute([$userId, $permissionSlug]);
        
        return $stmt->fetchColumn() > 0;
    }
}
