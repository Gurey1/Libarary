<?php

require_once __DIR__ . '/../models/AuditLog.php';

class Logger {
    public static function info($adminId, $action, $details, $entity = null, $entityId = null) {
        AuditLog::log($adminId, $action, $details, $entity, $entityId);
    }
}
