<?php

require_once __DIR__ . '/../config/database.php';

class AuditLog {
    
    public static function log($adminId, $action, $details = null) {
        $db = Database::getInstance();
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';

        $stmt = $db->prepare("INSERT INTO audit_logs (admin_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$adminId, $action, $details, $ip]);
    }
}
