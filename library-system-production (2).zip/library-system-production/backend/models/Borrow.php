<?php
class Borrow {
    private $conn;
    private $table = 'borrow_transactions';

    // Properties
    public $id;
    public $book_id;
    public $user_id;
    public $borrow_date;
    public $due_date;
    public $return_date;
    public $status; // 'borrowed', 'returned', 'late'

    public function __construct($db) {
        $this->conn = $db;
    }

    // Borrow a book
    public function borrowBook($book_id, $user_id, $due_date) {
        // Transaction to ensure data consistency
        try {
            $this->conn->beginTransaction();

            // 1. Check if book is available
            $checkQuery = "SELECT available_copies FROM books WHERE id = :book_id";
            $checkStmt = $this->conn->prepare($checkQuery);
            $checkStmt->bindParam(':book_id', $book_id);
            $checkStmt->execute();
            $book = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if (!$book || $book['available_copies'] < 1) {
                $this->conn->rollBack();
                return false; // Book not available
            }

            // 2. Insert into borrow_transactions
            $query = "INSERT INTO " . $this->table . " 
                      (book_id, user_id, borrow_date, due_date, status) 
                      VALUES (:book_id, :user_id, CURDATE(), :due_date, 'borrowed')";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':book_id', $book_id);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':due_date', $due_date);
            
            if (!$stmt->execute()) {
                $this->conn->rollBack();
                return false;
            }

            // 3. Update available_copies in books
            $updateQuery = "UPDATE books SET available_copies = available_copies - 1 WHERE id = :book_id";
            $updateStmt = $this->conn->prepare($updateQuery);
            $updateStmt->bindParam(':book_id', $book_id);
            
            if (!$updateStmt->execute()) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;

        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    // Return a book
    public function returnBook($borrow_id) {
        try {
            $this->conn->beginTransaction();

            // 1. Get book_id from borrow record
            $getQuery = "SELECT book_id, status FROM " . $this->table . " WHERE id = :id";
            $getStmt = $this->conn->prepare($getQuery);
            $getStmt->bindParam(':id', $borrow_id);
            $getStmt->execute();
            $record = $getStmt->fetch(PDO::FETCH_ASSOC);

            if (!$record || $record['status'] == 'returned') {
                $this->conn->rollBack();
                return false; // Already returned or invalid
            }

            $book_id = $record['book_id'];

            // 2. Update borrow_transactions
            $query = "UPDATE " . $this->table . " 
                      SET return_date = CURDATE(), status = 'returned' 
                      WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $borrow_id);
            
            if (!$stmt->execute()) {
                $this->conn->rollBack();
                return false;
            }

            // 3. Update available_copies in books
            $updateQuery = "UPDATE books SET available_copies = available_copies + 1 WHERE id = :book_id";
            $updateStmt = $this->conn->prepare($updateQuery);
            $updateStmt->bindParam(':book_id', $book_id);

            if (!$updateStmt->execute()) {
                $this->conn->rollBack();
                return false;
            }

            $this->conn->commit();
            return true;

        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    // Get all active borrowed books
    public function getAllBorrowed() {
        // Query to join with books and users for readable info
        $query = "SELECT br.id, b.title as book_title, u.full_name as user_name, br.borrow_date, br.due_date, br.status 
                  FROM " . $this->table . " br
                  JOIN books b ON br.book_id = b.id
                  JOIN users u ON br.user_id = u.id
                  WHERE br.status = 'borrowed' OR br.status = 'late'
                  ORDER BY br.borrow_date DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Get overdue books
    public function getOverdueBooks() {
        $query = "SELECT br.id, b.title as book_title, u.full_name as user_name, br.borrow_date, br.due_date, br.status 
                  FROM " . $this->table . " br
                  JOIN books b ON br.book_id = b.id
                  JOIN users u ON br.user_id = u.id
                  WHERE br.due_date < CURDATE() AND br.status != 'returned'
                  ORDER BY br.due_date ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Get borrow history
    public function getBorrowHistory() {
        $query = "SELECT br.id, b.title as book_title, u.full_name as user_name, br.borrow_date, br.due_date, br.return_date, br.status 
                  FROM " . $this->table . " br
                  JOIN books b ON br.book_id = b.id
                  JOIN users u ON br.user_id = u.id
                  ORDER BY br.borrow_date DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}