<?php

require_once __DIR__ . '/../config/database.php';

class Admin {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }

    public function login($username, $password) {
        $query = "SELECT id, username, password, role_id FROM admins WHERE username = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$username]);
        
        $admin = $stmt->fetch();
        
        if ($admin && password_verify($password, $admin['password'])) {
            unset($admin['password']); // Don't return hash
            return $admin;
        }
        
        return false;
    }

    public function saveRefreshToken($id, $token) {
        $query = "UPDATE admins SET refresh_token = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$token, $id]);
    }
    
    public function getByRefreshToken($token) {
        $query = "SELECT id, username, role_id FROM admins WHERE refresh_token = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$token]);
        return $stmt->fetch();
    }
    
    public function clearRefreshToken($id) {
        $query = "UPDATE admins SET refresh_token = NULL WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }
}
