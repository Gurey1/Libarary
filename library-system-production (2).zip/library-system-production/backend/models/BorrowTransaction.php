<?php

require_once __DIR__ . '/../config/database.php';

class BorrowTransaction {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function create($userId, $bookId, $dueDate) {
        $stmt = $this->conn->prepare("INSERT INTO borrow_transactions (user_id, book_id, due_date, borrow_date) VALUES (?, ?, ?, CURDATE())");
        return $stmt->execute([$userId, $bookId, $dueDate]);
    }
    
    public function getActiveTransaction($userId, $bookId) {
        $stmt = $this->conn->prepare("SELECT * FROM borrow_transactions WHERE user_id = ? AND book_id = ? AND status = 'borrowed'");
        $stmt->execute([$userId, $bookId]);
        return $stmt->fetch();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM borrow_transactions WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function markReturned($id, $returnDate, $status) {
        $stmt = $this->conn->prepare("UPDATE borrow_transactions SET return_date = ?, status = ? WHERE id = ?");
        return $stmt->execute([$returnDate, $status, $id]);
    }
    
    public function getHistory($filters = []) {
        $query = "SELECT bt.*, b.title as book_title, u.full_name as user_name 
                  FROM borrow_transactions bt 
                  JOIN books b ON bt.book_id = b.id 
                  JOIN users u ON bt.user_id = u.id 
                  WHERE 1=1";
        
        $params = [];
        
        if (isset($filters['user_id'])) {
            $query .= " AND bt.user_id = ?";
            $params[] = $filters['user_id'];
        }
        
        $query .= " ORDER BY bt.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
