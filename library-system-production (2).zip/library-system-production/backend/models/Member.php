<?php

require_once __DIR__ . '/../config/database.php';

class Member {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM members WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM members");
        return $stmt->fetchAll();
    }
    
    public function create($data) {
        $stmt = $this->conn->prepare("INSERT INTO members (name, email, phone) VALUES (?, ?, ?)");
        if ($stmt->execute([$data['name'], $data['email'], $data['phone']])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }
    
    public function updateStatus($id, $status) {
        $stmt = $this->conn->prepare("UPDATE members SET status = ? WHERE id = ?");
        return $stmt->execute([$status, $id]);
    }
}
