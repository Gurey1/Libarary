<?php

require_once __DIR__ . '/../config/database.php';

class Report {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function getSummary() {
        $summary = [];
        
        $summary['total_books'] = $this->conn->query("SELECT COUNT(*) FROM books WHERE deleted_at IS NULL")->fetchColumn();
        $summary['total_members'] = $this->conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $summary['total_borrowed'] = $this->conn->query("SELECT COUNT(*) FROM borrow_transactions WHERE status = 'borrowed'")->fetchColumn();
        $summary['total_overdue'] = $this->conn->query("SELECT COUNT(*) FROM borrow_transactions WHERE status = 'late' OR (status = 'borrowed' AND due_date < CURDATE())")->fetchColumn();
        
        return $summary;
    }
    
    public function getMostBorrowed() {
        $query = "SELECT b.title, COUNT(br.id) as borrow_count 
                  FROM borrow_transactions br 
                  JOIN books b ON br.book_id = b.id 
                  GROUP BY br.book_id 
                  ORDER BY borrow_count DESC 
                  LIMIT 5";
        return $this->conn->query($query)->fetchAll();
    }
    
    public function getOverdueBooks() {
        $query = "SELECT b.title, u.full_name as name, br.due_date 
                  FROM borrow_transactions br 
                  JOIN books b ON br.book_id = b.id 
                  JOIN users u ON br.user_id = u.id 
                  WHERE br.status = 'borrowed' AND br.due_date < CURDATE()";
        return $this->conn->query($query)->fetchAll();
    }

    public function getMonthlyBorrowings() {
        // Last 6 months
        $query = "SELECT DATE_FORMAT(borrow_date, '%Y-%m') as month, COUNT(*) as count 
                  FROM borrow_transactions 
                  WHERE borrow_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                  GROUP BY month 
                  ORDER BY month ASC";
        return $this->conn->query($query)->fetchAll();
    }

    public function getMonthlyFines() {
        // Last 6 months
        $query = "SELECT DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as total 
                  FROM fines 
                  WHERE status = 'paid' AND created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
                  GROUP BY month 
                  ORDER BY month ASC";
        return $this->conn->query($query)->fetchAll();
    }

    public function getBooksByCategory() {
        $query = "SELECT c.name, COUNT(bc.book_id) as count 
                  FROM categories c
                  LEFT JOIN book_categories bc ON c.id = bc.category_id 
                  GROUP BY c.id, c.name";
        return $this->conn->query($query)->fetchAll();
    }
}