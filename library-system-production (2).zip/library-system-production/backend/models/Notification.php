<?php

require_once __DIR__ . '/../config/database.php';

class Notification {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function create($data) {
        // data: message, type, member_id (optional), user_id (optional)
        $memberId = $data['member_id'] ?? null;
        $userId = $data['user_id'] ?? null;
        
        $stmt = $this->conn->prepare("INSERT INTO notifications (message, type, member_id, user_id) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$data['message'], $data['type'], $memberId, $userId]);
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM notifications ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }
}
