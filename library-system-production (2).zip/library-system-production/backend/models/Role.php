<?php

require_once __DIR__ . '/../config/database.php';

class Role {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }

    public function create($name) {
        $stmt = $this->conn->prepare("INSERT INTO roles (name) VALUES (?)");
        if ($stmt->execute([$name])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM roles");
        return $stmt->fetchAll();
    }

    public function assignPermission($roleId, $permissionId) {
        // Use Insert Ignore or check existence
        $stmt = $this->conn->prepare("INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
        return $stmt->execute([$roleId, $permissionId]);
    }
}
