<?php

require_once __DIR__ . '/../config/database.php';

class Fine {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function create($userId, $transactionId, $daysLate, $amount) {
        $stmt = $this->conn->prepare("INSERT INTO fines (user_id, transaction_id, days_late, amount, status) VALUES (?, ?, ?, ?, 'unpaid')");
        return $stmt->execute([$userId, $transactionId, $daysLate, $amount]);
    }
    
    public function getAll($userId = null) {
        $query = "SELECT f.*, u.full_name as user_name, b.title as book_title
                  FROM fines f
                  JOIN users u ON f.user_id = u.id
                  JOIN borrow_transactions bt ON f.transaction_id = bt.id
                  JOIN books b ON bt.book_id = b.id
                  WHERE 1=1";
        $params = [];
        
        if ($userId) {
            $query .= " AND f.user_id = ?";
            $params[] = $userId;
        }
        
        $query .= " ORDER BY f.created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
    
    public function pay($id) {
        $stmt = $this->conn->prepare("UPDATE fines SET status = 'paid' WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
