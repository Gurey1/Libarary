<?php

require_once __DIR__ . '/../config/database.php';

class Setting {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT setting_key, setting_value FROM settings");
        return $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // Returns ['key' => 'value']
    }
    
    public function get($key, $default = null) {
        $stmt = $this->conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $value = $stmt->fetchColumn();
        return $value !== false ? $value : $default;
    }
    
    public function update($key, $value) {
        $stmt = $this->conn->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        return $stmt->execute([$key, $value, $value]);
    }
}
