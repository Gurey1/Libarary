<?php

require_once __DIR__ . '/../config/database.php';

class Permission {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }

    public function create($name) {
        $stmt = $this->conn->prepare("INSERT INTO permissions (name) VALUES (?)");
        if ($stmt->execute([$name])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM permissions");
        return $stmt->fetchAll();
    }

    // Static check method for Middleware usage without checking 'slug' vs 'name' confusion
    public static function check($userId, $permissionName) {
        $db = Database::getInstance();
        
        // Super Admin Check
        $adminStmt = $db->prepare("SELECT r.name FROM admins a JOIN roles r ON a.role_id = r.id WHERE a.id = ?");
        $adminStmt->execute([$userId]);
        $roleName = $adminStmt->fetchColumn();
        
        if ($roleName === 'Super Admin') {
            return true;
        }

        // Standard Check
        $query = "
            SELECT COUNT(*) 
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            JOIN admins a ON a.role_id = rp.role_id
            WHERE a.id = ? AND p.name = ?
        ";
        $stmt = $db->prepare($query);
        $stmt->execute([$userId, $permissionName]);
        
        return $stmt->fetchColumn() > 0;
    }
}
