<?php

require_once __DIR__ . '/../config/database.php';

class User {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    
    public function isActive($id) {
        $user = $this->getById($id);
        return $user && $user['status'] === 'Active';
    }

    public function hasUnpaidFines($id) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) FROM fines WHERE user_id = ? AND status = 'unpaid'");
        $stmt->execute([$id]);
        return $stmt->fetchColumn() > 0;
    }
}
