<?php

require_once __DIR__ . '/../config/database.php';

class Book {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance();
    }

    public function getAll($filters = []) {
        $query = "SELECT b.*, 
                  GROUP_CONCAT(DISTINCT c.name) as categories, 
                  GROUP_CONCAT(DISTINCT t.name) as tags 
                  FROM books b
                  LEFT JOIN book_categories bc ON b.id = bc.book_id
                  LEFT JOIN categories c ON bc.category_id = c.id
                  LEFT JOIN book_tags bt ON b.id = bt.book_id
                  LEFT JOIN tags t ON bt.tag_id = t.id
                  WHERE b.deleted_at IS NULL";
        
        $params = [];

        if (!empty($filters['search'])) {
            $query .= " AND (b.title LIKE ? OR b.author LIKE ?)";
            $params[] = "%" . $filters['search'] . "%";
            $params[] = "%" . $filters['search'] . "%";
        }
        
        if (!empty($filters['category'])) {
            $query .= " AND c.name = ?";
            $params[] = $filters['category'];
        }

        if (!empty($filters['tag'])) {
            $query .= " AND t.name = ?";
            $params[] = $filters['tag'];
        }

        $query .= " GROUP BY b.id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $query = "SELECT * FROM books WHERE id = ? AND deleted_at IS NULL";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function create($data) {
        $query = "INSERT INTO books (title, author, isbn, published_year, total_copies, available_copies, location) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($query);
        if ($stmt->execute([$data['title'], $data['author'], $data['isbn'], $data['published_year'], $data['total_copies'], $data['total_copies'], $data['location']])) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function update($id, $data) {
        $query = "UPDATE books SET title = ?, author = ?, isbn = ?, published_year = ?, total_copies = ?, location = ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$data['title'], $data['author'], $data['isbn'], $data['published_year'], $data['total_copies'], $data['location'], $id]);
    }

    public function softDelete($id) {
        $query = "UPDATE books SET deleted_at = NOW() WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }

    public function attachCategories($bookId, $categoryIds) {
        $stmt = $this->conn->prepare("INSERT IGNORE INTO book_categories (book_id, category_id) VALUES (?, ?)");
        foreach ($categoryIds as $catId) {
            $stmt->execute([$bookId, $catId]);
        }
    }
    
    public function attachTags($bookId, $tagIds) {
        $stmt = $this->conn->prepare("INSERT IGNORE INTO book_tags (book_id, tag_id) VALUES (?, ?)");
        foreach ($tagIds as $tagId) {
            $stmt->execute([$bookId, $tagId]);
        }
    }
    
    // For restoration (optional utility)
    public function restore($id) {
        $query = "UPDATE books SET deleted_at = NULL WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([$id]);
    }
}
