<?php

class Database {
    private $host = "localhost";
    private $db_name = "library_db";
    private $username = "root";
    private $password = ""; 
    public $conn;

    private static $instance = null;

    private function __construct() {
        $this->conn = null;

        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            // In a real production env, log this error instead of verifying. 
            // For now, return JSON error if connection fails.
            header('Content-Type: application/json');
            echo json_encode(["status" => "error", "message" => "Connection failed: " . $exception->getMessage()]);
            exit;
        }
    }

    public static function getInstance() {
        if (!self::$instance) {
            self::$instance = new Database();
        }
        return self::$instance->conn;
    }
}
